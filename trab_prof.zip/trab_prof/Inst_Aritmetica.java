package Sintaxe.Instrucoes;
import Sintaxe.Instrucao;

public abstract class Inst_Aritmetica extends Instrucao{

}
