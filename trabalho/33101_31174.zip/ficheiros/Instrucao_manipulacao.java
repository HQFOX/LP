
public abstract class Instrucao_manipulacao extends Instrucao{
}
