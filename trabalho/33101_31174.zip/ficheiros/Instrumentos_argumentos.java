
public abstract class Instrucao_argumentos extends Instrucao{
}
