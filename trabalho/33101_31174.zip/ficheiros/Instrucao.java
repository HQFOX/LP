public abstract class Instrucao{

	public abstract void executa(CIMS maquina);

	public abstract String toString();

}
