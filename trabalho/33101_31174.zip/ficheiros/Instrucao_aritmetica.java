
public abstract class Instrucao_aritmetica extends Instrucao{
}
