public class Regressa extends Instrucao_chamada{




	public String toString(){
		return "regressa";
	}
}
