public class Chama extends Instrucao_chamada{

int a;
String e;

	public Chama(int a, String e)
	{
		this.a = a;
		this.e = e;
	}

	public String toString(){
		return "chama " + a + " "+ e;
	}
}
