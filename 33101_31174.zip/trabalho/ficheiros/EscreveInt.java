public class EscreveInt extends Instrucao_saida{


	public String toString(){
		return "escreve int";
	}
}
