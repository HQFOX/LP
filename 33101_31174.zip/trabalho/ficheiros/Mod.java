public class Mod extends Instrucao_aritmetica{


	public String toString(){
		return "mod";
	}
}
