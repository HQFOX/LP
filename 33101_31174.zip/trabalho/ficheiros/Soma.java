public class Soma extends Instrucao_aritmetica{


	public String toString(){
		return "soma";
	}
}
