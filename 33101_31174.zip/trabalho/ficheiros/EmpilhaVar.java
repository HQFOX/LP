public class EmpilhaVar extends Instrucao_acesso{

int a;

int b;

	public EmpilhaVar(int a, int b)
	{
		this.a = a;
		this.b = b;
	}
	public String toString(){
		return "empilha var " + a + " " + b ;
	}
}
