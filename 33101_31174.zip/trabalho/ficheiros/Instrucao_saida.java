
public abstract class Instrucao_saida extends Instrucao{
}
