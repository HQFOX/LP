public class ColocaArg extends Instrucao_chamada{

int a;
	public ColocaArg(int a)
	{
		this.a = a;
	}
	public String toString(){
		return "coloca arg" + a;
	}
}
