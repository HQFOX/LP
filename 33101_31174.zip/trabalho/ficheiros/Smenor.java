public class Smenor extends Instrucao_salto{


String e;

	public Smenor(String e)
	{
		this.e = e;

	}


	public String toString(){
		return "smenor";
	}
}
