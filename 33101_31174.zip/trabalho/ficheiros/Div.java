public class Div extends Instrucao_aritmetica{


	public String toString(){
		return "div";
	}
}
