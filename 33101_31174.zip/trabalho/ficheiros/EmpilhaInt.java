public class EmpilhaInt extends Instrucao_manipulacao{

int a;

int b;

	public EmpilhaInt(int a)
	{
		this.a = a;
	}
	public String toString()
	{
		return "empilha " + a;
	}
}
