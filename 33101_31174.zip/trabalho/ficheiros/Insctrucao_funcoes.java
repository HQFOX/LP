
public abstract class Instrucao_funcoes extends Instrucao{

	public String toString();
}
