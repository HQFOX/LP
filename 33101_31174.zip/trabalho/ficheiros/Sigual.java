public class Sigual extends Instrucao_salto{

String e;

	public Sigual(String e)
	{
		this.e = e;
	}

	public String toString(){
		return "sigual";
	}
}
