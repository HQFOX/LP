public abstract class Instrucao{

	public abstract String toString();

}
