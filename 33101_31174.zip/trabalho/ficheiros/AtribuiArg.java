public class AtribuiArg extends Instrucao_acesso{

int a;
int b;
	public AtribuiArg(int a, int b)
	{
		this.a = a;
		this.b = b;
	}

	public String toString(){
		return "coloca arg" + a + " " + b ;
	}
}
