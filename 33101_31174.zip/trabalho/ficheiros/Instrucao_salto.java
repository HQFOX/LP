
public abstract class Instrucao_salto extends Instrucao{

}
