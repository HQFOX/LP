public class MudaLinha extends Instrucao_saida{


	public String toString(){
		return "muda linha";
	}
}
