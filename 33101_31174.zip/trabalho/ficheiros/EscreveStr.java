public class EscreveStr extends Instrucao_saida{

	String str;

	public EscreveStr(String str)
	{
		this.str = str;
	}

	public String toString(){
		return "escreve str" + str;
	}
}
