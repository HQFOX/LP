
public abstract class Instrucao_acesso extends Instrucao{
}
