public class EmpilhaArg extends Instrucao_acesso{

int a;

int b;

	public EmpilhaArg(int a, int b)
	{
		this.a = a;
		this.b = b;
	}
	public String toString()
	{
		return "empilha arg " + a + " " + b ;
	}
}
