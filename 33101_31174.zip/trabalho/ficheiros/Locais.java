public class Locais extends Instrucao_chamada{

int a;
int b;

	public Locais(int a, int b)
	{
		this.a = a;
		this.b = b;
	}

	public String toString(){
		return "locais " + a +" "+ b;
	}
}
