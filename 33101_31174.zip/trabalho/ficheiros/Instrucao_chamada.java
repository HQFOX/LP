
public abstract class Instrucao_chamada extends Instrucao{

}
