public class Mult extends Instrucao_aritmetica{


	public String toString(){
		return "mult";
	}
}
