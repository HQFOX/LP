
// Conjunto de Instrucoes Maquina Simplimport java.util.ArrayList;
import java.util.ArrayList;


public class CIMS {
  /** Executa o programa CIMS carregado na maquina. */

	ArrayList<Etiquetas> etiquetas;

	public CIMS ()
	{
		etiquetas = new ArrayList<Etiquetas>();
	}

	public ArrayList<Etiquetas> getMemoria()
	{
		return etiquetas;
	}
	
	public void executa()
	{
	  
	}
	
	public Etiquetas getLast()
	{
		if(etiquetas.size()>0)
			return etiquetas.get((etiquetas.size()-1));
		else return null;
	}
	
	public void print()
	{
		for(int i = 0; i< etiquetas.size() ; i++)
		{
			etiquetas.get(i).print();
		}
	}
}
