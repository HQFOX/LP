public class Sub extends Instrucao_aritmetica{


	public String toString(){
		return "sub";
	}
}
