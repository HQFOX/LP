public class Exp extends Instrucao_aritmetica{


	public String toString(){
		return "exp";
	}
}
