public class AtribuiVar extends Instrucao_acesso{

int a;

int b;

	public AtribuiVar(int a, int b)
	{
		this.a = a;
		this.b = b;
	}
	public String toString(){
		return "atribui var" + a + " " + b ;
	}
}
